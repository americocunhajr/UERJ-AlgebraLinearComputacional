clc; clear; close all;
L = [0 1.26 2.0; 0.164 0 0; 0 0.808 0.808];
[V,lambda] = eig(L);
[GrowthRate,idx] = max(abs(diag(lambda)))
EquilPop = V(:,idx)/sum(V(:,idx))
N = 20; X = zeros(3,N); 
X(:,1) = [1; 1; 1];
for n = 1:N-1
    X(:,n+1) = L*X(:,n);
end
figure; hold on; 
plot(1:N,X(1,:),'*r','DisplayName','G1');
plot(1:N,X(2,:),'og','DisplayName','G2');
plot(1:N,X(3,:),'db','DisplayName','G3');
legend; set(gca,'FontSize',20);
xlabel('time'); ylabel('population');