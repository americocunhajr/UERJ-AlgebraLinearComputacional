clc; clear;

t = [0.1 0.2 0.3 0.4 0.5];
h = [5.49 -9.45 -31.39 -75.59 -113.69]*1e-2;
A = [0.5*t.^2; t; ones(size(t))]';
b = h';
x = A\b;

xfit = 0:0.01:0.5; 
yfit = 0.5*x(1)*xfit.^2 + x(2)*xfit + x(3);

plot(t,h,'om','LineWidth',2);
hold on; 
plot(xfit,yfit,'-b','LineWidth',2);
hold off; 
xlabel('tempo'); ylabel('altura'); 
set(gca,'FontSize',18);