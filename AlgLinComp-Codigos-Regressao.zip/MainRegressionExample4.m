clc; clear; close all;

dados = load('covid19_casos_rio_2020_2021.csv');

mm7 = dados;
for j=7:length(dados)
    mm7(j) = sum(dados(j-6:j))/7;
end

xdata = 1:21; ydata = mm7(xdata)';
A     = [xdata; ones(size(xdata))]';
b     = log(ydata)';
x     = A\b;
yfit  = @(z) exp(x(2))*exp(x(1)*z);

stem(dados(1:31),'oc','LineWidth',0.5);
hold on
plot(1:31,  mm7(1:31),'-.r','LineWidth',1);
plot(yfit(1:31),'-y','LineWidth',3);
plot(yfit(1:21),'-k','LineWidth',3);
hold off
xlabel('dias decorridos'); ylabel('novos casos por dia');
set(gca,'FontSize',18);
