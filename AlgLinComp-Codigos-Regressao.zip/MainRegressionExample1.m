clc; clear;

m  = 10;
xd = randn(m,1);
yd = -2*xd + 1 + randn(size(xd));
A  = [sum(xd.^2) sum(xd); sum(xd) m];
b  = [sum(xd.*yd); sum(yd)];
x  = A\b;

xfit = min(xd):0.01:max(xd);
yfit = x(1)*xfit + x(2);

plot(xd,yd,'om','LineWidth',2);
hold on;
plot(xfit,yfit,'-b','LineWidth',2);
hold off; 
xlabel('x'); ylabel('y'); 
set(gca,'FontSize',18);