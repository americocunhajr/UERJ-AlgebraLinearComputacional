clc; clear;

A = [-2 0 1; 1 3 1; 1 2 0]

[L,U] = lu(A)
A-L*U