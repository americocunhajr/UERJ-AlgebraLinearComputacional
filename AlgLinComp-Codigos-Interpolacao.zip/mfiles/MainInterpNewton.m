
clc
clear
close all

xdata = [1;2;4]; ydata = [1;3;3];

p0 = @(x)  1*ones(size(x));
p1 = @(x) p0(x) + 2*(x-1);
p2 = @(x) p1(x) - (2/3)*(x-1).*(x-2);
xgrid = 0:0.01:5;

figure(1)
plot(xdata,ydata,'om','LineWidth',2);
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','Location','south')
xlim([0 5]);
ylim([-4 10]);
saveas(gcf,'interp_newton1.png')

figure(2)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot([xdata(1),xdata(1)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-4,10],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','Location','south')
xlim([0 5]);
ylim([-4 10]);
saveas(gcf,'interp_newton2.png')

figure(3)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,p0(xgrid),'--r','LineWidth',2)
plot([xdata(1),xdata(1)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-4,10],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','p0(x)','Location','south')
xlim([0 5]);
ylim([-4 10]);
saveas(gcf,'interp_newton3.png')

figure(4)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,p0(xgrid),'--r','LineWidth',1)
plot(xgrid,p1(xgrid),'-.c','LineWidth',2)
plot([xdata(1),xdata(1)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-4,10],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','p0(x)','p1(x)','Location','south')
xlim([0 5]);
ylim([-4 10]);
saveas(gcf,'interp_newton4.png')

figure(5)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,p0(xgrid),'--r','LineWidth',1)
plot(xgrid,p1(xgrid),'-.c','LineWidth',2)
plot(xgrid,p2(xgrid), '-b','LineWidth',2)
plot([xdata(1),xdata(1)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-4,10],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-4,10],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','p0(x)','p1(x)','p2(x)','Location','south')
xlim([0 5]);
ylim([-4 10]);
saveas(gcf,'interp_newton5.png')

