clc; clear; close all

xdat = [1;2;4]; ydat = [1;3;3];

p0 = @(x)  1*ones(size(x));
p1 = @(x) p0(x) + 2*(x-1);
p2 = @(x) p1(x) - (2/3)*(x-1).*(x-2);
xgrid = 0:0.01:5;
