
clc
clear
close all

% start random number generator and fix the statistical seed
% --------------------------------------------------------------
rng_stream = RandStream('mt19937ar','Seed',01012020);
RandStream.setGlobalStream(rng_stream);
% --------------------------------------------------------------

% complicate function
% --------------------------------------------------------------
x = 0.1:0.01:10;
y = log(x).*exp(sqrt(x))./(log(1+exp(x))+x.^3);

n = 5;
xdata = [1.3 2.1 4.0 5.8 8.1];
ydata = log(xdata).*exp(sqrt(xdata))./(log(1+exp(xdata))+xdata.^3);

A = [xdata.^4; xdata.^3; xdata.^2; xdata; ones(1,n)]';
b = ydata';
alpha = A\b;

v1 = alpha(1)*x.^4 + alpha(2)*x.^3 + alpha(3)*x.^2 + alpha(4)*x + alpha(5);

A = [exp(-xdata.^2); exp(-xdata); xdata.^2; xdata; ones(1,n)]';
b = ydata';
alpha = A\b;

v2 = alpha(1)*exp(-x.^2) + alpha(2)*exp(-x) + ...
     alpha(3)*x.^2 + alpha(4)*x + alpha(5);

figure(1)
plot(xdata,ydata,'om','LineWidth',2);
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','northwest')
xlim([0 10]);
ylim([0 0.5]);
saveas(gcf,'datapoints_complicated1.png')


figure(2)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(x,y,'--k','LineWidth',2);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','curva real','northwest')
xlim([0 10]);
ylim([0 0.5]);
saveas(gcf,'datapoints_complicated2.png')

figure(3)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(x,y, '--k','LineWidth',2);
plot(x,v1,'-.r','LineWidth',2);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','curva real','funcao interpolante 1','northwest')
xlim([0 10]);
ylim([0 0.5]);
saveas(gcf,'datapoints_complicated3.png')

figure(4)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(x,y, '--k','LineWidth',2);
plot(x,v1,'-.r','LineWidth',2);
plot(x,v2, '-b','LineWidth',2);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','curva real','funcao interpolante 1','funcao interpolante 2','northwest')
xlim([0 10]);
ylim([0 0.5]);
saveas(gcf,'datapoints_complicated4.png')
% --------------------------------------------------------------


% cubic
% --------------------------------------------------------------
xdata = -1:1:2;
ydata = 2*xdata.^3 - 3*xdata.^2 -3*xdata + 2 + 0.01*randn(size(xdata));

A = vander(xdata);
b = ydata';
alpha = A\b

x = -3:0.01:3;
yinterp = polyval(alpha,x);

A = [xdata.^5; xdata.^2; ones(length(xdata))]';
b = ydata';
alpha = A\b

yfit = polyval(alpha,x);



figure(5)
plot(xdata,ydata,'om','LineWidth',2);
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
xlim([-3 3]);
ylim([-10 10]);
saveas(gcf,'datapoints_cubic_noiseless.png')


figure(6)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(x,yfit,'-b','LineWidth',3);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
xlim([-3 3]);
ylim([-10 10]);
saveas(gcf,'datapoints_cubic_noiseless_ls.png')


figure(7)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(x,yinterp,'-b','LineWidth',3);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
xlim([-3 3]);
ylim([-10 10]);
saveas(gcf,'datapoints_cubic_noiseless_interp.png')
% --------------------------------------------------------------

