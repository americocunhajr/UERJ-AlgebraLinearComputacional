clc; clear; close all;

xd = [1;2;4]; yd = [1;3;3];
p0 = @(x)  1*ones(size(x));
p1 = @(x) p0(x) + 2*(x-1);
p2 = @(x) p1(x) - (2/3)*(x-1).*(x-2);
xg = 0:0.01:5;

plot(xd,yd,'om','LineWidth',2);
hold on
plot(xg,p0(xg),'--r','LineWidth',2);
plot(xg,p1(xg),'-.c','LineWidth',2);
plot(xg,p2(xg), '-b','LineWidth',2);
plot([xd(1),xd(1)],[-4,10],'--k','LineWidth',0.5);
plot([xd(2),xd(2)],[-4,10],'--k','LineWidth',0.5);
plot([xd(3),xd(3)],[-4,10],'--k','LineWidth',0.5);
hold off
xlabel('x'); ylabel('y'); 
set(gca,'FontSize',18);
xlim([0 5]); ylim([-4 10]);
legend('dados','p_0(x)','p_1(x)','p_2(x)','Location','south')
