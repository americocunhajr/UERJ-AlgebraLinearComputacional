clc; clear; close all

xd = [1; 2; 4]; 
yd = [1; 3; 3];

xg = 0:0.01:5;
yg = InterpLagrange(xd,yd,xg);

plot(xg,yg,'b',xd,yd,'or');