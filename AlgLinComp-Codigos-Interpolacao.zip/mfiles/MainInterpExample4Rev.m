clc; clear; close all;

xd1 = [1; 2; 4];    yd1 = [1; 3; 3];
xd2 = [1; 2; 4; 5]; yd2 = [1; 3; 3; 2];

[c1,tab1] = DivDif(xd1,yd1);
[c2,tab2] = DivDifAdd(xd2,yd2,tab1);

xg = 0:0.01:5;
yg1 = InterpNewton(xg,xd1,c1);
yg2 = InterpNewton(xg,xd2,c2);

plot(xg,yg1,'b');
hold on
plot(xg,yg2,'g',xd2,yd2,'or');
hold off