clc; clear; close all;

xd = [1;2;4]; 
yd = [1;3;3];

A    = vander(xd)
xsol = A\yd

p = @(x) polyval(xsol, x);
xg = 0:0.01:5; 
yg = p(xg);

plot(xd,yd,'om','LineWidth',2);
hold on;
plot(xg,yg,'-b','LineWidth',2);
hold off;
xlabel('x'); ylabel('y'); 
set(gca,'FontSize',18);
legend('dados','p(x)','Location','south');