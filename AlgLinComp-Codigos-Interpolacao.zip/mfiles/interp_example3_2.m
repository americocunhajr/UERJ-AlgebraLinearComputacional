plot(xdat,ydat,'om',xgrid,ygrid,'-b','LineWidth',2)
hold on
plot(xgrid,L2(xgrid),'--r','LineWidth',1)
plot(xgrid,L1(xgrid),'-.c','LineWidth',1)
plot(xgrid,L0(xgrid), ':g','LineWidth',1)
plot([xdat(1),xdat(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdat(2),xdat(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdat(3),xdat(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x'); ylabel('y');
set(gca,'FontSize',18);
legend('dados','p(x)','L2','L1','L0','Location','best')

