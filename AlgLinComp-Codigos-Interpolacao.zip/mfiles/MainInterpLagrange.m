
clc
clear
close all



% complicate function
% --------------------------------------------------------------
xdata = [1;2;4]; ydata = [1;3;3];

L0 = @(x)  (1/3)*(x-2).*(x-4);
L1 = @(x) -(1/2)*(x-1).*(x-4);
L2 = @(x)  (1/6)*(x-1).*(x-2);
p =  @(x) ydata(3)*L2(x) + ydata(2)*L1(x) + ydata(1)*L0(x);
xgrid = 0:0.01:5; ygrid = p(xgrid);

figure(1)
plot(xdata,ydata,'om','LineWidth',2);
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange1.png')

figure(2)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot([xdata(1),xdata(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange2.png')

figure(3)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,L2(xgrid),'--r','LineWidth',1)
plot([xdata(1),xdata(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','L2','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange3.png')

figure(4)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,L2(xgrid),'--r','LineWidth',1)
plot(xgrid,L1(xgrid),'-.c','LineWidth',1)
plot([xdata(1),xdata(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','L2','L1','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange4.png')

figure(5)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,L2(xgrid),'--r','LineWidth',1)
plot(xgrid,L1(xgrid),'-.c','LineWidth',1)
plot(xgrid,L0(xgrid), ':g','LineWidth',1)
plot([xdata(1),xdata(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','L2','L1','L0','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange5.png')

figure(6)
plot(xdata,ydata,'om','LineWidth',2);
hold on
plot(xgrid,L2(xgrid),'--r','LineWidth',1)
plot(xgrid,L1(xgrid),'-.c','LineWidth',1)
plot(xgrid,L0(xgrid), ':g','LineWidth',1)
plot(xgrid,ygrid,'-b','LineWidth',2)
plot([xdata(1),xdata(1)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(2),xdata(2)],[-3,4],'--k','LineWidth',0.5);
plot([xdata(3),xdata(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x')
ylabel('y')
set(gcf,'color','white');
set(gca,'position',[0.2 0.2 0.7 0.7]);
set(gca,'Box','on');
set(gca,'TickDir','out','TickLength',[.02 .02]);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'XGrid','off','YGrid','off');
set(gca,'XColor',[.3 .3 .3],'YColor',[.3 .3 .3]);
set(gca,'FontName','Helvetica');
set(gca,'FontSize',18);
legend('dados','L2','L1','L0','p(x)','Location','south')
xlim([0 5]);
ylim([-3 4]);
saveas(gcf,'interp_lagrange6.png')
% --------------------------------------------------------------


