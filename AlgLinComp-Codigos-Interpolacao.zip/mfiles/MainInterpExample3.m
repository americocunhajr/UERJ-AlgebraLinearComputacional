clc; clear; close all;

xd = [1;2;4]; yd = [1;3;3];

L0 = @(x)  (1/3)*(x-2).*(x-4);
L1 = @(x) -(1/2)*(x-1).*(x-4);
L2 = @(x)  (1/6)*(x-1).*(x-2);
p  = @(x) yd(3)*L2(x) + yd(2)*L1(x) + yd(1)*L0(x);

xg = 0:0.01:5; yg = p(xg);

plot(xd,yd,'om','LineWidth',2);
hold on
plot(xg,L2(xg),'--r','LineWidth',1);
plot(xg,L1(xg),'-.c','LineWidth',1);
plot(xg,L0(xg), ':g','LineWidth',1);
plot(xg,yg,'-b','LineWidth',2);
plot([xd(1),xd(1)],[-3,4],'--k','LineWidth',0.5);
plot([xd(2),xd(2)],[-3,4],'--k','LineWidth',0.5);
plot([xd(3),xd(3)],[-3,4],'--k','LineWidth',0.5);
hold off
xlabel('x'); ylabel('y'); 
set(gca,'FontSize',18);
legend('dados','L2','L1','L0','p(x)','Location','south');