function [coef,tab] = DivDif(xd,yd)
   n = length(xd)-1;
   tab = zeros(n+1,n+1); 
   xd = shiftdim(xd); 
   yd = shiftdim(yd);
   tab(1:n+1,1) = yd;
   for k = 2:n+1
      num = tab(k:n+1,k-1)-tab(k-1:n,k-1);
      den = xd(k:n+1)-xd(1:n+1-k+1);
      tab(k:n+1,k) = num./den;
   end
   coef = diag(tab);
end
