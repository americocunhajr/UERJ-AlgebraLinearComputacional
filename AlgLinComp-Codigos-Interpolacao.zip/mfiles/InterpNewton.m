function y = InterpNewton(x,xd,coef)
  n = length(xd);
  y = coef(n)*ones(size(x));
  for j=n-1:-1:1
    y = y.*(x - xd(j)) + coef(j);
  end
end
