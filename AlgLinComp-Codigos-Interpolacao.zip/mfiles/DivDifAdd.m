function [coef,tab] = DivDifAdd(xd,yd,tab)
   n = length(xd)-1;
   tab = [tab zeros(n,1); yd(n+1) zeros(1,n)];
   for k=2:n+1
      num = tab(n+1,k-1)-tab(n,k-1);
      den = xd(n+1)-xd(n+1-k+1);
      tab(n+1,k) = num/den;
   end
   coef = diag(tab);
end
