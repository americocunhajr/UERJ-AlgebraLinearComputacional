plot(xdat,ydat,'om','LineWidth',2);
hold on
plot(xgrid,ygrid, '--k','LineWidth',2);
plot(xgrid,p1,'-.r','LineWidth',2);
plot(xgrid,p2, '-b','LineWidth',2);
hold off
xlabel('x'); ylabel('y');
set(gca,'FontSize',18);
legend('dados','f(x)','p1(x)','p2(x)')
xlim([0 10]); ylim([0 0.5]);