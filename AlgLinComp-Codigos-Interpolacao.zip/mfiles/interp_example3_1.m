clc; clear; close all

xdat = [1;2;4]; ydat = [1;3;3];

L0 = @(x)  (1/3)*(x-2).*(x-4);
L1 = @(x) -(1/2)*(x-1).*(x-4);
L2 = @(x)  (1/6)*(x-1).*(x-2);
p =  @(x) ydat(3)*L2(x) + ydat(2)*L1(x) + ydat(1)*L0(x);
xgrid = 0:0.01:5; ygrid = p(xgrid);

