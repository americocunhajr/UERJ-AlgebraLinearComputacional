clc; clear;
e = 1e-16;
A = [1, 1, 1; 1, 1+e, 1-e; 0, 1-e, 1+e];
b = [3; 3; 2];
fprintf('Cond. number A: %e\n',cond(A));

[L,U,P] = lu(A);
x_lu = U\L\(P*b)

x_svd = pinv(A)*b

fprintf('Residual LU : %e\n',norm(A*x_lu-b));
fprintf('Residual SVD: %e\n',norm(A*x_svd-b));