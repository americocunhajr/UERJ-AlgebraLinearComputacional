clc; clear;
m = 200; n = 150; a = randn(m,1); e = 1.0e-5;
A = (a*ones(1,n)).*(ones(m,n)+e*randn(m,n));
Q = zeros(m,n); R = zeros(n,n);
for j = 1:n
    Q(:,j) = A(:,j);
    for i = 1:j-1
        R(i,j) = Q(:,i)'*A(:,j);
        Q(:,j) = Q(:,j) - R(i,j)*Q(:,i);
    end
    R(j,j) = norm(Q(:,j));
    Q(:,j) = Q(:,j)/R(j,j);
end
norm(A-Q*R)
norm(Q'*Q-eye(n,n))