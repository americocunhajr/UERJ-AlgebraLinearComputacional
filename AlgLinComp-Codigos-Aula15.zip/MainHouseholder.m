clc; clear;
m = 200; n = 150; a = randn(m,1); e = 1.0e-5;
A = (a*ones(1,n)).*(ones(m,n)+e*randn(m,n));
Q = eye(m,m); R = A; r = min(m-1,n);
for k = 1:r
  a = R(k:m,k);
  e1 = zeros(length(a),1); e1(1) = 1;
  u = sign(a(1))*norm(a)*e1 + a;
  u = u/norm(u);
  for j = k:n
    R(k:m,j) = R(k:m,j) - 2*u*(u'*R(k:m,j));
  end
  I = eye(k-1,k-1); O = zeros(k-1,m+1-k);
  Qhat = eye(m-k+1,m-k+1)-2*u*(u');
  Q = Q*[I O; O' Qhat];
end
R = triu(R);
norm(A-Q*R)
norm(Q'*Q-eye(m,m))