clc; clear; close all;

% Define R, G e B vectors
r = [255;0;0]; g = [0;255;0]; b = [0;0;255];

% new color are linear combination of RGB
y = 0.5*r + 0.5*g + 0.0*b;

% show the colors in images
figure(1); ShowColor(r);
figure(2); ShowColor(g);
figure(3); ShowColor(b);
figure(4); ShowColor(y);

function ShowColor(MyColor)
  img = uint8(ones(100,100,3);
  img = img.*reshape(MyColor,[1, 1, 3]));
  imshow(img); pause(1);
end