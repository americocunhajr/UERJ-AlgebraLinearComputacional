clc; clear; close all;

NameFiles = dir('*.jpg');
N         = length(NameFiles); 
VGImages  = cell(N, 1);

for n = 1:N
   CurrentFileName = NameFiles(n).name;
   CurrentImage    = imread(CurrentFileName);
   VGImages{n}     = CurrentImage;
end

function v = Image2Vector(ImageRGB)
    v = reshape(double(ImageRGB/256),[],1);
end

function cos_theta = Similarity(v1,v2)
    cos_theta = dot(v1/norm(v1),v2/norm(v2));
end

function vn = Normalize01(v)
    vn = (v-min(v))/(max(v)-min(v));
end

ImgN = zeros(N/2, 1);
ImgS = zeros(N/2, N/2);
ImgD = zeros(N/2, N/2);

for m = 1:N/2
   Img1      = Image2Vector(VGImages{N/2+m});
   ImgN(m,1) = norm(Img1);
   
   for n = 1:N/2
      Img2      = Image2Vector(VGImages{n});
      ImgS(m,n) = Similarity(Img1,Img2);
      ImgD(m,n) = norm(Img1-Img2);
   end
   
   ImgS(m,:) = Normalize01(ImgS(m,:));
   ImgD(m,:) = Normalize01(ImgD(m,:));
end

figure(1); imagesc(Normalize01(ImgN));
title('Brightness of Images'); 
c1 = colorbar; set(c1, 'FontSize', 24);
set(gca,'FontSize', 20,'XTickLabel', []);

figure(2); imagesc(ImgS); 
title('Similarity between images');
c2 = colorbar; set(c2, 'FontSize', 24);
set(gca,'FontSize', 20); 

figure(3); imagesc(ImgD); 
title('Distance between images');
c3 = colorbar; set(c3, 'FontSize', 24);
set(gca,'FontSize', 20); 