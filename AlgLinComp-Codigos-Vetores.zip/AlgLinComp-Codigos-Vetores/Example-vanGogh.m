clc; clear; close all;

ImageFiles = dir('*.jpg');
Nfiles     = length(ImageFiles); 
ImagesRGB  = cell(Nfiles, 1);

for n = 1:Nfiles
   CurrentFileName = ImageFiles(n).name;
   CurrentImage    = imread(CurrentFileName);
   ImagesRGB{n}    = CurrentImage;
end

function v = ImageRGB2Vector(ImageRGB)
    v = reshape(double(ImageRGB/256),[],1);
end

function cos_theta = VectorSimilarity(v1,v2)
    cos_theta = dot(v1,v2)/(norm(v1)*norm(v2));    
end

ImagesNorm       = zeros(Nfiles, 1); 
ImagesSimilarity = zeros(Nfiles, Nfiles);

for m = 1:Nfiles 
   Img1      = ImageRGB2Vector(ImagesRGB{m});
   ImgN(m,1) = norm(Img1);

   for n = 1:Nfiles
      Img2      = ImageRGB2Vector(ImagesRGB{n});
      ImgS(m,n) = VectorSimilarity(Img1,Img2);
   end
end

figure(1); imshow(ImgN/max(ImgN))
figure(2); imshow(ImgS)